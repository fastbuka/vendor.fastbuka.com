"use client";
import dynamic from "next/dynamic";
import React from "react";
import CardDataStats from "../CardDataStats";

const ECommerce: React.FC = () => {
  return (
    <>
      <h1 className="font-bold text-xl my-3">Hi, Rodinia </h1>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-6 md:gap-6 xl:grid-cols-6 2xl:gap-7.5">
        <div className="col-span-3 bg-[#f2f9ff]">
          <div className="p-3">
            <h1 className="font-medium text-xl">Your Balance</h1>
            <h1 className="font-black text-3xl">$19,000</h1>
          </div>
        </div>
        <div>yo</div>
        <div>yo</div>
        <div>yo</div>
      </div>

      <div className="mt-4 grid grid-cols-12 gap-4 md:mt-6 md:gap-6 2xl:mt-7.5 2xl:gap-7.5">
        <div className="col-span-12 xl:col-span-8"></div>
      </div>
    </>
  );
};

export default ECommerce;
